-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2023 at 04:49 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pyb`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `unumber` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pkgname` varchar(255) NOT NULL,
  `pickdate` varchar(255) NOT NULL,
  `dropdate` varchar(255) NOT NULL,
  `noofseat` int(11) NOT NULL,
  `adults` int(11) NOT NULL,
  `child` int(11) NOT NULL,
  `pickloc` varchar(255) NOT NULL,
  `droploc` varchar(255) NOT NULL,
  `date1` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `uname`, `unumber`, `email`, `pkgname`, `pickdate`, `dropdate`, `noofseat`, `adults`, `child`, `pickloc`, `droploc`, `date1`) VALUES
(3, 'varun', '9325301476', 'kadamvarun94@gmail.com', '', '2023-02-10', '2023-02-24', 10, 5, 5, 'aurangabad', 'pune', '2023-02-08'),
(5, 'nayan kadam', '7517607254', 'kadamvarun94@gmail.com', '', '2023-02-10', '2023-02-22', 12, 11, 1, 'aurangabad', 'pune', '2023-02-09'),
(36, 'Harshvardhan', '7517607254', 'bharshvardhan4@gmail.com', 'mahableshwar', '2023-02-18', '2023-02-20', 10, 8, 2, 'aurangabad', 'pune', '2023-02-11'),
(37, 'Avinash Raut', '7517607254', 'vraut0761@gmail.com', 'mahableshwar', '2023-02-17', '2023-02-21', 4, 4, 0, 'aurangabad', 'pune', '2023-02-12'),
(38, 'nayan kadam', '7517607254', 'kadamvarun94@gmail.com', 'mathurai', '2023-02-15', '2023-02-16', 10, 8, 2, 'aurangabad', 'pune', '2023-02-12'),
(39, 'abcd', '1234557891', 'kadamvarun94@gmail.com', 'mahableshwar', '2023-02-16', '2023-02-24', 10, 10, 0, 'aurangabad', 'aurangabad', '2023-02-13'),
(40, 'abcd', '1234557891', 'kadamvarun94@gmail.com', 'mahableshwar', '2023-02-09', '2023-02-24', 10, 10, 0, 'aurangabad', 'aurangabad', '2023-02-13'),
(41, 'abcd', '1234557891', 'kadamvarun94@gmail.com', 'mahableshwar', '0001-02-10', '0020-02-20', 10, 10, 0, 'aurangabad', 'aurangabad', '2023-02-13'),
(42, 'abcd', '1234557891', 'kadamvarun94@gmail.com', 'mahableshwar', '2023-02-16', '2023-02-18', 10, 10, 0, 'aurangabad', 'aurangabad', '2023-02-13'),
(43, 'mansi ahire', '9405992089', 'ahiremansi02@gmail.com', 'mahableshwar', '2023-02-14', '2023-02-15', 10, 5, 5, 'Aurangabad', 'Aurangabad', '2023-02-13'),
(44, 'nayan kadam', '7517607254', 'kadamvarun94@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 12, 8, 4, 'Aurangabad', 'pune', '2023-02-15'),
(45, 'Varun', '7517607254', 'kadamvarun94@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 10, 8, 2, 'Aurangabad', 'pune', '2023-02-15'),
(46, 'Varun', '7517607254', 'kadamvarun94@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 12, 11, 1, 'Aurangabad', 'pune', '2023-02-15'),
(47, 'Adinath', '7517607254', 'adinaththote77@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 4, 2, 2, 'Aurangabad', 'pune', '2023-02-15'),
(48, 'Adinath Thote', '7517607254', 'adinaththote77@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 4, 4, 0, 'Aurangabad', 'pune', '2023-02-15'),
(49, 'Adinath Thote', '7517607254', 'adinaththote77@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 4, 5, 1, 'Aurangabad', 'pune', '2023-02-15'),
(50, 'Varun', '9420417205', 'adinaththote77@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 12, 11, 1, 'Aurangabad', 'pune', '2023-02-15'),
(51, 'Adinath Thote', '7517607254', 'adinaththote77@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 12, 11, 1, 'Aurangabad', 'pune', '2023-02-15'),
(52, 'Varun', '7517607254', 'adinaththote77@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 12, 11, 1, 'Aurangabad', 'pune', '2023-02-15'),
(53, 'Adinath Thote', '7517607254', 'adinaththote77@gmail.com', 'mathurai', '2023-02-14', '2023-02-20', 12, 11, 1, 'Aurangabad', 'pune', '2023-02-15'),
(54, 'GANESH PANGUDE', '7888169227', 'pangudeganesh9227@gmail.com', 'mahableshwar', '2023-02-14', '2023-02-20', 10, 4, 6, 'Aurangabad', 'pune', '2023-03-21');

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE `detail` (
  `id` int(11) NOT NULL,
  `city` varchar(20) NOT NULL,
  `description` varchar(225) NOT NULL,
  `image` varchar(200) NOT NULL,
  `date1` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`id`, `city`, `description`, `image`, `date1`) VALUES
(1, 'MAHARASHTRA', 'Maharashtra is located along the western coast of India. The state boasts thickly forested hills and valleys that are home to diverse flora and fauna, ancient caves, and a rich cultural heritage.', 'maharashtra.jpg', '2023-01-20'),
(2, 'TELANGANA', 'Telangana is located in the southern part of India and is renowned for its natural attractions, temples, palaces, forts, and other heritage sites. The rich cultural heritage of the state makes it one ', 'hyderabad.jpg', '2023-01-20'),
(3, 'RAJASTHAN', 'Rajasthan is famous for textiles, semi-precious stones, and handicrafts, as well as for its traditional and colorful art. Rajasthani furniture is known for its intricate carvings and bright colors.', 'rajasthan.jpg', '2023-01-20'),
(4, 'GUJARAT', '  The state of Gujarat boasts vibrant art, architecture, culture, and heritage; all of which are quite evident in the day-to-day lives of the locals. The diversity exhibited by Gujarat is a result of the various ethnic gujara', 'gujrat.jpg', '2023-01-21'),
(5, 'HIMACHAL PRADESH', 'Himachal is well known for its handicrafts. The carpets, leather works, shawls, paintings, metalware and woodwork are worth appreciating. Pashmina shawl is one of the products which is highly in deman', 'himachalpradesh.jpg', '2023-01-20'),
(6, 'LADAKH', 'Ladakh is also called “Little Tibet” because of its cultural & geographical resemblance with Tibet.3000 meters above sea level Ladakh is the highest plateau in the state of Jammu and Kashmir.', 'ladakh.jpg', '2023-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `pkgcitytour`
--

CREATE TABLE `pkgcitytour` (
  `id` int(11) NOT NULL,
  `city` varchar(225) NOT NULL,
  `pkgname` varchar(225) NOT NULL,
  `pkgdes` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL,
  `date1` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pkgcitytour`
--

INSERT INTO `pkgcitytour` (`id`, `city`, `pkgname`, `pkgdes`, `image`, `date1`) VALUES
(1, 'maharashtra', 'mahableshwar', 'mahableshwar is great city to explore and vary naturefull city to explore.', 'elephanta.jpg', '2023-01-21'),
(2, 'TELANGANA', 'chennai', 'tamilnadu is great city to explore where we can explore the temple.', 'tamil.jpg', '2023-01-21'),
(3, 'TELANGANA', 'mathurai', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'kailash.jpg', '2023-03-05'),
(5, 'goa', 'Green Escapes', 'Sure Goa packages are not hard to find and probably are your best bet if you want to live the tried and tested. The popular imagination sums up Goa as a zone for dissipation limited to its beaches, hippie spots, party zones w', 'ashutosh-saraswat-CXyz3qljaH8-unsplash.jpg', '2023-02-11'),
(7, 'maharashtra', 'MaharashtraDEMO1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ', 'Raigad.jpg', '2023-03-05'),
(8, 'maharashtra', 'MaharashtraDEMO2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Haroshchandra-gad.jpg', '2023-03-05'),
(9, 'TELANGANA', 'TelanganaDEMO3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'chowalla.jpg', '2023-03-05'),
(10, 'RAJASTHAN', 'RajasthanDEMO1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'background.png', '2023-03-05'),
(11, 'RAJASTHAN', 'RajasthanDEMO2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'pic-4.png', '2023-03-05'),
(12, 'RAJASTHAN', 'RajasthanDEMO3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'rajasthan.jpg', '2023-03-05'),
(13, 'GUJARAT', 'GujaratDEMO1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Gujarat3.jpg', '2023-03-05'),
(14, 'GUJARAT', 'GujaratDEMO2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'gujrat.jpg', '2023-03-05'),
(15, 'GUJARAT', 'GujaratDEMO3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Gujrat2.jpg', '2023-03-05'),
(16, 'HIMACHAL PRADESH', 'Himachal pradeshDEMO1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Himachal.jpg', '2023-03-05'),
(17, 'HIMACHAL PRADESH', 'Himachal pradeshDEMO2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Himachal2.jpg', '2023-03-05'),
(18, 'HIMACHAL PRADESH', 'Himachal pradeshDEMO3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Himachal3.jpg', '2023-03-05'),
(19, 'LADAKH', 'LadakhDEMO1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ', 'ladakh.jpg', '2023-03-05'),
(20, 'LADAKH', 'LadakhDEMO2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Ladakh2.jpg', '2023-03-05'),
(21, 'LADAKH', 'LadakhDEMO3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor', 'Ladakh23.jpg', '2023-03-05'),
(22, 'maharashtra', 'mahademo4', 'demo', 'Haroshchandra-gad.jpg', '2023-03-15');

-- --------------------------------------------------------

--
-- Table structure for table `pkgdetail`
--

CREATE TABLE `pkgdetail` (
  `id` int(11) NOT NULL,
  `pkgname` varchar(255) NOT NULL,
  `pkgprice` int(11) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `tourlength` varchar(255) NOT NULL,
  `startdate` varchar(255) NOT NULL,
  `enddate` varchar(255) NOT NULL,
  `day1` varchar(255) NOT NULL,
  `day2` varchar(255) NOT NULL,
  `day3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pkgdetail`
--

INSERT INTO `pkgdetail` (`id`, `pkgname`, `pkgprice`, `image1`, `tourlength`, `startdate`, `enddate`, `day1`, `day2`, `day3`) VALUES
(9, 'mahableshwar', 10000, 'maharashtra.jpg', '6N/7D', '2023-02-14', '2023-02-20', 'Day1', 'Day2', 'Day3'),
(13, 'mathurai', 10000, '', '6N/7D', '2023-02-14', '2023-02-20', 'day1', 'day2', 'day3'),
(14, 'chennai', 20000, 'kailash.jpg', '6N/7D', '2023-02-22', '2023-02-28', 'Day1', 'Day2', 'Day3'),
(15, 'MaharashtraDEMO1', 10000, 'Raigad.jpg', '6N/7D', '2023-03-05', '2023-03-12', 'DAY1', 'DAY2', 'DAY3'),
(16, 'MaharashtraDEMO2', 10000, 'maharashtra.jpg', '6N/7D', '2023-03-05', '2023-03-12', 'DAY1', 'DAY2', 'DAY3'),
(17, 'TelanganaDEMO3', 10000, 'abd2.jpg', '6N/7D', '2023-03-07', '2023-03-13', 'DAY1', 'DAY2', 'DAY3'),
(18, 'RajasthanDEMO1', 10000, 'rajasthan.jpg', '6N/7D', '2023-03-07', '2023-03-13', 'DAY1', 'DAY2', 'DAY3'),
(19, 'RajasthanDEMO2', 10000, 'pic-2.png', '6N/7D', '2023-03-07', '2023-03-13', 'DAY1', 'DAY2', 'DAY3'),
(20, 'RajasthanDEMO3', 10000, 'background.png', '6N/7D', '2023-03-07', '2023-03-13', 'DAY1', 'DAY2', 'DAY3'),
(21, 'GujaratDEMO1', 10000, 'gujrat.jpg', '6N/7D', '2023-03-07', '2023-03-13', 'DAY1', 'DAY2', 'DAY3'),
(22, 'GujaratDEMO2', 10000, 'Gujarat3.jpg', '6N/7D', '2023-03-07', '2023-03-13', 'DAY1', 'DAY2', 'DAY3'),
(23, 'GujaratDEMO3', 10000, 'Gujrat2.jpg', '6N/7D', '2023-03-07', '2023-03-13', 'DAY1', 'DAY2', 'DAY3');

-- --------------------------------------------------------

--
-- Table structure for table `pkgimage`
--

CREATE TABLE `pkgimage` (
  `id` int(11) NOT NULL,
  `pkgname` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pkgimage`
--

INSERT INTO `pkgimage` (`id`, `pkgname`, `image`) VALUES
(42, 'mahableshwar', 'Raigad.jpg'),
(43, 'mahableshwar', 'Haroshchandra-gad.jpg'),
(44, 'MaharashtraDEMO1', 'Haroshchandra-gad.jpg'),
(45, 'MaharashtraDEMO2', 'Raigad.jpg'),
(46, 'chennai', '4hdb.jpg'),
(47, 'TelanganaDEMO3', 'chowalla.jpg'),
(48, 'TelanganaDEMO3', '1hbd.jpg'),
(49, 'RajasthanDEMO1', 'pic-1.png'),
(50, 'RajasthanDEMO1', 'background.png'),
(51, 'RajasthanDEMO2', 'background.png'),
(52, 'RajasthanDEMO2', 'pic-3.png'),
(53, 'RajasthanDEMO3', 'pic-4.png'),
(54, 'RajasthanDEMO3', 'rajasthan.jpg'),
(55, 'GujaratDEMO1', 'Gujrat2.jpg'),
(56, 'GujaratDEMO1', 'Gujarat3.jpg'),
(57, 'GujaratDEMO2', 'gujrat.jpg'),
(58, 'GujaratDEMO2', 'Gujrat2.jpg'),
(59, 'GujaratDEMO3', 'Gujarat3.jpg'),
(60, 'GujaratDEMO3', 'gujrat.jpg'),
(61, 'GujaratDEMO3', 'Gujrat2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `signup_detail`
--

CREATE TABLE `signup_detail` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `cpass` varchar(20) NOT NULL,
  `date1` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup_detail`
--

INSERT INTO `signup_detail` (`id`, `fname`, `lname`, `address`, `email`, `pass`, `cpass`, `date1`) VALUES
(10, 'Adinath', 'Thote', 'aurangabad', 'adinaththote77@gmail.com', 'Afd3#@62362', 'Afd3#@62362', '2023-02-12'),
(12, 'Varun', 'Kadam', 'RH-40/22 Ashwamegh Hosing Society , BajajNagar , Aurangabad', 'kadamvarun94@gmail.com', 'Varun@29802', 'Varun@29802', '2023-02-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pkgcitytour`
--
ALTER TABLE `pkgcitytour`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pkgdetail`
--
ALTER TABLE `pkgdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pkgimage`
--
ALTER TABLE `pkgimage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup_detail`
--
ALTER TABLE `signup_detail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `detail`
--
ALTER TABLE `detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pkgcitytour`
--
ALTER TABLE `pkgcitytour`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `pkgdetail`
--
ALTER TABLE `pkgdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `pkgimage`
--
ALTER TABLE `pkgimage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `signup_detail`
--
ALTER TABLE `signup_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
